-- Run this in Supabase SQL Editor for EACH buyer's separate Supabase project.
-- One project per buyer provides strong practical separation between customers/businesses.
create extension if not exists pgcrypto;

create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references auth.users(id) on delete cascade,
  name text not null default 'Your Barbershop',
  tagline text not null default 'Premium Cuts & Grooming for the Modern Gentleman.',
  intro text not null default 'Clean cuts, detailed beard work and a welcoming experience.',
  phone text not null default '',
  whatsapp text not null default '',
  address text not null default '',
  hours text not null default '',
  map_url text not null default '',
  payment_note text not null default 'Ask the shop for approved payment instructions.',
  created_at timestamptz not null default now()
);

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 100),
  description text not null default '' check (char_length(description) <= 250),
  price numeric(10,2) not null check (price >= 0 and price <= 100000),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  service_id uuid references public.services(id) on delete set null,
  customer_name text not null check (char_length(customer_name) between 1 and 100),
  customer_phone text not null check (char_length(customer_phone) between 3 and 30),
  appointment_date date not null,
  appointment_time time not null,
  service_name text not null,
  status text not null default 'pending' check (status in ('pending','confirmed','completed','cancelled')),
  created_at timestamptz not null default now()
);

alter table public.businesses enable row level security;
alter table public.services enable row level security;
alter table public.bookings enable row level security;

-- Public visitors may see business details, but cannot see private auth records.
create policy "Public can view shop profile" on public.businesses
  for select to anon, authenticated using (true);
create policy "Owner can update own business" on public.businesses
  for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "Owner can view own business" on public.businesses
  for select to authenticated using (owner_id = auth.uid());

-- Public can view active services; only the owner can create/update/delete services.
create policy "Public can view active services" on public.services
  for select to anon, authenticated using (active = true);
create policy "Owner can view all own services" on public.services
  for select to authenticated using (
    exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
  );
create policy "Owner can add own services" on public.services
  for insert to authenticated with check (
    exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
  );
create policy "Owner can update own services" on public.services
  for update to authenticated using (
    exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
  ) with check (
    exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
  );
create policy "Owner can delete own services" on public.services
  for delete to authenticated using (
    exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
  );

-- Public visitors may submit booking requests but cannot read bookings.
create policy "Public can submit booking request" on public.bookings
  for insert to anon, authenticated with check (
    exists (select 1 from public.businesses b where b.id = business_id)
    and exists (select 1 from public.services s where s.id = service_id and s.business_id = bookings.business_id and s.active = true)
    and appointment_date >= current_date
  );
create policy "Owner can read own bookings" on public.bookings
  for select to authenticated using (
    exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
  );
create policy "Owner can update own bookings" on public.bookings
  for update to authenticated using (
    exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
  ) with check (
    exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
  );

-- Create the business profile automatically when a new owner account is registered.
create or replace function public.create_business_for_new_owner()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.businesses (owner_id, name)
  values (new.id, coalesce(nullif(split_part(coalesce(new.email, ''), '@', 1), ''), 'Your Barbershop'))
  on conflict (owner_id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_create_business on auth.users;
create trigger on_auth_user_created_create_business
after insert on auth.users
for each row execute procedure public.create_business_for_new_owner();

-- Starter services for each new business are intentionally not seeded automatically.
-- Owner should add real services and prices through the dashboard.

-- Price edits are protected by the services UPDATE policy above: only an authenticated
-- owner whose auth.uid() owns the related business can update a service row.
-- Never expose the Supabase service_role key in index.html.
